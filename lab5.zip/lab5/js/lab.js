//  Define Variables
make = "Volkswagon";
model = "Bus";
color = "Sage Green";
year = 1967;

// calculate
age = 2019 - 1967;

// output
document.writeln("Make: " + make + "<br>");
document.writeln("Model: " + model + "<br>");
document.writeln("Color: " + color + "<br>");
document.writeln("Year: " + year + "<br>");
document.writeln("Age: " + age + " years<br>");
